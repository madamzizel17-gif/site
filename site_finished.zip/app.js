// app.js - frontend
const API_BASE = "/api/outages";

const map = L.map('map', {zoomControl:true}).setView([48.4647, 35.0462], 12);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

let marker = null;

function setMarker(lat, lon){
  if (marker) marker.remove();
  marker = L.marker([lat, lon]).addTo(map);
  map.setView([lat, lon], 14);
}

async function fetchOutages(lat, lon){
  const outDiv = document.getElementById("outagesList");
  outDiv.innerHTML = "Загрузка...";
  try {
    const resp = await fetch(`${API_BASE}?lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}`);
    if (!resp.ok) {
      const err = await resp.json().catch(()=>({error:'Ошибка'}));
      throw new Error(err.error || 'Ошибка сервера');
    }
    const data = await resp.json();
    renderOutages(data, outDiv);
  } catch (err) {
    outDiv.innerHTML = `<div class="outage">Ошибка получения данных: ${err.message}</div>`;
  }
}

function renderOutages(data, container){
  const list = Array.isArray(data) ? data : (data.outages || []);
  if (!list.length){
    container.innerHTML = `<div class="outage">Отключений не найдено по данному месту.</div>`;
    return;
  }
  container.innerHTML = "";
  list.forEach(item => {
    const el = document.createElement("div");
    el.className = "outage";
    const from = item.from ? item.from : "";
    const to = item.to ? item.to : "";
    el.innerHTML = `
      <strong>${item.street || item.area || 'Район'}</strong>
      <div class="meta">${from ? 'c ' + from : ''} ${to ? 'по ' + to : ''}</div>
      <div style="margin-top:8px;color:#475569">${item.reason || 'Плановые работы'}</div>
    `;
    container.appendChild(el);
  });
}

// click map
map.on("click", (e) => {
  const { lat, lng } = e.latlng;
  setMarker(lat, lng);
  fetchOutages(lat, lng);
});

// geolocation
document.getElementById("geoBtn").addEventListener("click", () => {
  if (!navigator.geolocation) {
    alert("Геолокация не поддерживается в этом браузере.");
    return;
  }
  navigator.geolocation.getCurrentPosition(pos => {
    const lat = pos.coords.latitude;
    const lon = pos.coords.longitude;
    setMarker(lat, lon);
    fetchOutages(lat, lon);
  }, err => {
    alert("Не удалось получить геолокацию: " + err.message);
  });
});

// search via Nominatim
document.getElementById("searchBtn").addEventListener("click", async () => {
  const q = document.getElementById("addrInput").value.trim();
  if (!q) return;
  try {
    const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(q + ', Dnipro, Ukraine')}`);
    const items = await res.json();
    if (!items || items.length === 0) {
      alert("Адрес не найден");
      return;
    }
    const first = items[0];
    const lat = parseFloat(first.lat);
    const lon = parseFloat(first.lon);
    setMarker(lat, lon);
    fetchOutages(lat, lon);
  } catch (e) {
    alert("Ошибка поиска: " + e.message);
  }
});
