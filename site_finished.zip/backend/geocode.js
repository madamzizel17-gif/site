const fetch = require("node-fetch");
const { NOMINATIM_URL } = require("./config");

async function reverseGeocode(lat, lon) {
    const url = `${NOMINATIM_URL}/reverse?lat=${lat}&lon=${lon}&format=json&addressdetails=1`;

    const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0" }
    });

    const data = await res.json();
    if (!data.address) return null;

    return {
        street: data.address.road,
        house: data.address.house_number
    };
}

async function searchAddress(query) {
    const url = `${NOMINATIM_URL}/search?q=${encodeURIComponent(query)}&format=json&addressdetails=1&limit=1`;

    const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0" }
    });

    const data = await res.json();

    if (!data.length) return null;

    const addr = data[0].address;

    return {
        street: addr.road,
        house: addr.house_number,
        lat: data[0].lat,
        lon: data[0].lon
    };
}

module.exports = { reverseGeocode, searchAddress };
