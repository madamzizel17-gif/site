module.exports = {
    PORT: 3000,
    NOMINATIM_URL: "https://nominatim.openstreetmap.org",
    DTEK_FIND_GROUP_URL: "https://www.dtek-dnem.com.ua/api/pc/FindOffGroup",
    DTEK_SCHEDULE_URL: "https://www.dtek-dnem.com.ua/api/pc/FindShutdownSchedule",
    CACHE_TTL: 10 * 60 * 1000 // 10 минут
};
