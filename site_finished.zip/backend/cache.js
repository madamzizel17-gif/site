class Cache {
    constructor(ttl) {
        this.ttl = ttl;
        this.data = new Map();
    }

    set(key, value) {
        this.data.set(key, { value, time: Date.now() });
    }

    get(key) {
        const item = this.data.get(key);
        if (!item) return null;
        if (Date.now() - item.time > this.ttl) {
            this.data.delete(key);
            return null;
        }
        return item.value;
    }
}

module.exports = Cache;
