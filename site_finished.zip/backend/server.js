const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

// Serve static frontend
app.use(express.static(path.join(__dirname, '..')));

// Simple API: /api/outages?lat=..&lon=..
app.get('/api/outages', (req, res) => {
  const lat = parseFloat(req.query.lat);
  const lon = parseFloat(req.query.lon);
  if (Number.isNaN(lat) || Number.isNaN(lon)) {
    return res.status(400).json({ error: 'Неверные координаты' });
  }

  // Example: generate some mock outages based on coordinates (for demo)
  const sample = [
    { street: "ул. Центральная, 12", from: "2025-11-20 09:00", to: "2025-11-20 15:00", reason: "Плановые работы" },
    { street: "ул. Лесная, 5", from: "2025-11-21 10:00", to: "2025-11-21 14:00", reason: "Техническое обслуживание" },
    { street: "пр. Гагарина", from: "2025-11-22 08:00", to: "2025-11-22 12:00", reason: "Замена трансформатора" }
  ];

  // simple distance check (mock): if lat/lon close to Dnipro center, return all, otherwise subset
  const center = {lat:48.4647, lon:35.0462};
  const dx = Math.abs(lat - center.lat);
  const dy = Math.abs(lon - center.lon);
  let result = sample;
  if (dx > 0.5 || dy > 0.5) {
    result = sample.slice(0,1);
  }
  res.json(result);
});

app.listen(PORT, () => {
  console.log('Server started on port', PORT);
});
