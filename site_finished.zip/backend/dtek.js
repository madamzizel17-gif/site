const fetch = require("node-fetch");
const { DTEK_FIND_GROUP_URL, DTEK_SCHEDULE_URL } = require("./config");

const headers = {
    "User-Agent": "Mozilla/5.0",
    "Accept": "application/json, text/plain, */*",
    "Referer": "https://www.dtek-dnem.com.ua/ua/shutdowns"
};

async function getGroup(street, house) {
    const url = `${DTEK_FIND_GROUP_URL}?street=${encodeURIComponent(street)}&house=${encodeURIComponent(house)}`;
    const res = await fetch(url, { headers });
    const data = await res.json();
    return data?.group || null;
}

async function getSchedule(group) {
    const url = `${DTEK_SCHEDULE_URL}?group=${group}`;
    const res = await fetch(url, { headers });
    const data = await res.json();
    return data?.schedule || [];
}

function parseSchedule(schedule) {
    const now = new Date();
    let nextOn = null;
    let nextOff = null;

    for (const block of schedule) {
        const start = new Date(block.start);
        const end = new Date(block.end);

        if (!nextOff && block.status === "off" && start > now) {
            nextOff = start.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
        }

        if (!nextOn && block.status === "on" && start > now) {
            nextOn = start.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
        }
    }

    return { nextOn, nextOff };
}

module.exports = { getGroup, getSchedule, parseSchedule };
